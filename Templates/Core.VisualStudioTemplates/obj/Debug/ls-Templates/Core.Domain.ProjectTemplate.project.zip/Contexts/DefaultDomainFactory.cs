﻿namespace Sfa.$safeprojectname$.Contexts
{
    public class DefaultDomainFactory : IDomainFactory
    {
        
    }
}