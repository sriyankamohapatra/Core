﻿namespace Sfa.$safeprojectname$.Contexts
{
    /// <summary>
    /// Defines the implementation of the factory for creating domain objects.
    /// </summary>
    public interface IDomainFactory
    {
        
    }
}