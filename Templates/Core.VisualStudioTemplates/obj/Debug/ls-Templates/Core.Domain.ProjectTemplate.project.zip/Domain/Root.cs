﻿namespace Sfa.$safeprojectname$.Domain
{
    public class Root
    {
        
    }
}