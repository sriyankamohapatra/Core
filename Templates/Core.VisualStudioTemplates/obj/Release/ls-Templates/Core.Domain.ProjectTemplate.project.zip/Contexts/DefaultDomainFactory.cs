﻿namespace $safeprojectname$.Contexts
{
    public class DefaultDomainFactory
    {
        
    }
}