﻿namespace $safeprojectname$.Domain
{
    public class Root
    {
        
    }
}